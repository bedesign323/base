
<div id="header-container">
	<header>
		<div id="logo"><a href="/"></a></div>
		
		<nav>
			<div class="menu-toggle">Menu</div>
			<?php print render($page['nav_main']); ?>
		</nav> 

		<div class="social-icons">
			<a href="http://twitter.com/theartistreport" class="icon-twitter" target="_blank"></a>
			<a href="http://instagram.com/theartistreport" class="icon-instagram" target="_blank"></a>
			<a href="https://www.youtube.com/channel/UC1TF5VhiFgWw0c61vnTA6Tw" class="icon-youtube" target="_blank"></a>
		</div>
	</header>
</div>

<div id="main-container">
	<div class="main">
		<?php print render($page['content']); ?>
	</div>
</div>

<div id="footer-container">
	<footer>
		<div class="inner">
			<div class="footer-main"><?php print render($page['footer_main']); ?></div>
			<div class="footer-left"><?php print render($page['footer_left']); ?></div>
			<div class="footer-right"><?php print render($page['footer_right']); ?></div>
		</div>
		<div class="copy">
			&copy; <?php echo date('Y') . ' ' . $site_name; ?>
		</div>
	</footer>
</div>
