<div class="teaser">
	<div class="cover-image">
		<?php echo $cover_image; ?>
		<h2 class="title"><?php echo $title; ?></h2>
	</div>
	<div class="info">
		<div class="links"><?php echo $service_links; ?></div>
		<div class="desc"><?php echo $body; ?></div>
		<div class="tags"><?php echo $sections; ?><?php echo $tags; ?></div>
	</div>
	<div class="divider"></div>
</div>
