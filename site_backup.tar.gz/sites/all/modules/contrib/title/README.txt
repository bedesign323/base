
-- SUMMARY --

Title module allows entity titles/labels to be fully translatable.

For a full description of the module, visit the project page:
  http://drupal.org/project/title
To submit bug reports and feature suggestions, or to track changes:
  http://drupal.org/project/issues/title


-- REQUIREMENTS --

* @todo


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONFIGURATION --

* @todo


-- USAGE --

* @todo


-- CONTACT --

Current maintainers:
* Francesco Placella (plach) - http://drupal.org/user/183211
* Daniel F. Kudwien (sun) - http://drupal.org/user/54136

